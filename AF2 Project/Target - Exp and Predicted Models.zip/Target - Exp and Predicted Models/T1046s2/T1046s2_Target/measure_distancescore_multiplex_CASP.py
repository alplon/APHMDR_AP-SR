import os
import os.path
import re
import csv
from biopandas.mol2 import PandasMol2
from biopandas.pdb import PandasPdb
import pandas as pd

root_dir = os.getcwd()
pmol = PandasMol2()
ppdb = PandasPdb()



ligandmol2 = pmol.read_mol2('/Users/alexplonski/Desktop/AlphaFoldProject/CASP-14/Docking/T1046s2/T1046s2_AlphaFold/ECMDB00125.mol2')
ATOM = pmol.df

ref = (0, 0, 0)
distances = ligandmol2.distance(xyz=ref)
distances_df = pd.DataFrame({'Distance':distances, 'X':ATOM['x'],'Y':ATOM['y'],'Z':ATOM['z']})


largestdistance_df = distances_df.nlargest(1, 'Distance')
x_large_filtered_df = pd.DataFrame(largestdistance_df, columns =['X'])
y_large_filtered_df = pd.DataFrame(largestdistance_df, columns =['Y'])
z_large_filtered_df = pd.DataFrame(largestdistance_df, columns =['Z'])
x_large_array = x_large_filtered_df.to_numpy()
y_large_array = y_large_filtered_df.to_numpy()
z_large_array = z_large_filtered_df.to_numpy()


smallestdistance_df = distances_df.nsmallest(1, 'Distance')
x_small_filtered_df = pd.DataFrame(smallestdistance_df, columns =['X'])
y_small_filtered_df = pd.DataFrame(smallestdistance_df, columns =['Y'])
z_small_filtered_df = pd.DataFrame(smallestdistance_df, columns =['Z'])
x_small_array = x_small_filtered_df.to_numpy()
y_small_array = y_small_filtered_df.to_numpy()
z_small_array = z_small_filtered_df.to_numpy()


x_midpoint = x_small_array + ((x_large_array - x_small_array)/2)
#print(x_midpoint)
y_midpoint = y_small_array + ((y_large_array - y_small_array)/2)
#print(y_midpoint)
z_midpoint = z_small_array + ((z_large_array - z_small_array)/2)
#print(z_midpoint)

x_coords = ATOM['x'].to_numpy()
y_coords = ATOM['y'].to_numpy()
z_coords = ATOM['z'].to_numpy()


x_coord_differences = []
for item in x_coords:
    x_coord_differences.append(item - x_midpoint)
x_abs_max = max(x_coord_differences, key = abs)
x_abs_max_coord = x_midpoint + x_abs_max

y_coord_differences = []
for item in y_coords:
    y_coord_differences.append(item - y_midpoint)
y_abs_max = max(y_coord_differences, key = abs)
y_abs_max_coord = y_midpoint + y_abs_max

z_coord_differences = []
for item in z_coords:
    z_coord_differences.append(item - z_midpoint)
z_abs_max = max(z_coord_differences, key = abs)
z_abs_max_coord = z_midpoint + z_abs_max


x_coord_differences_2 = []
for item in x_coords:
    x_coord_differences_2.append(item - x_abs_max_coord)
x_abs_max_2 = max(x_coord_differences_2, key = abs)
x_abs_max_2_coord = (x_abs_max_coord + x_abs_max_2)
x_abs_max_list = (x_abs_max_coord, x_abs_max_2_coord)
x_abs_max_list_sorted = sorted(x_abs_max_list)
x_upper = x_abs_max_list_sorted[1]
x_lower = x_abs_max_list_sorted[0]

y_coord_differences_2 = []
for item in y_coords:
    y_coord_differences_2.append(item - y_abs_max_coord)
y_abs_max_2 = max(y_coord_differences_2, key = abs)
y_abs_max_2_coord = (y_abs_max_coord + y_abs_max_2)
y_abs_max_list = (y_abs_max_coord, y_abs_max_2_coord)
y_abs_max_list_sorted = sorted(y_abs_max_list)
y_upper = y_abs_max_list_sorted[1]
y_lower = y_abs_max_list_sorted[0]

z_coord_differences_2 = []
for item in z_coords:
    z_coord_differences_2.append(item - z_abs_max_coord)
z_abs_max_2 = max(z_coord_differences_2, key = abs)
z_abs_max_2_coord = (z_abs_max_coord + z_abs_max_2)
z_abs_max_list = (z_abs_max_coord, z_abs_max_2_coord)
z_abs_max_list_sorted = sorted(z_abs_max_list)
z_upper = z_abs_max_list_sorted[1]
z_lower = z_abs_max_list_sorted[0]

x_center_array = x_lower + ((x_upper - x_lower)/2)
y_center_array = y_lower + ((y_upper - y_lower)/2)
z_center_array = z_lower + ((z_upper - z_lower)/2)

x_center = x_center_array.item(0)
y_center = y_center_array.item(0)
z_center = z_center_array.item(0)

native_ligand_center = x_center,y_center,z_center
print(native_ligand_center)

"""
                    proteinpdb = ppdb.read_pdb(native_pdbpath)
                    ATOM = ppdb.df['ATOM']=ppdb.df['ATOM']
                    #print(ATOM)
                    
                    ndistance = proteinpdb.distance(xyz = native_ligand_center, records=('ATOM',))
                    ndistancedf = pd.DataFrame({'ORG Residue': ATOM['residue_name'], 'ORG Residue Number': ATOM['residue_number'], 'ORG Residue Atom': ATOM['atom_name'], 'ORG Distance': ndistance, 'ORG Ligand': template_name, 'ORG Protein': protein_name+"_Target", 'ORG Score': best_score, 'ORG Drug X': x_center, 'ORG Drug Y': y_center, 'ORG Drug Z': z_center}, columns=['ORG Protein','ORG Ligand','ORG Residue','ORG Residue Number', 'ORG Residue Atom', 'ORG Distance', 'ORG Score', 'ORG Drug X', 'ORG Drug Y', 'ORG Drug Z'])
                    ndistancedf_small = ndistancedf.nsmallest(1, 'ORG Distance')
                    #print(distancedf_small)
                    reference_residue = ndistancedf_small['ORG Residue Number'].to_numpy()
                    nappended_smalldistance.append(ndistancedf_small)
                

                    
                    template_name = os.path.splitext(fn)[0]
                    mutant_mol2path = os.path.join(mutant_folders, 'ligandoutput', fn)
                    os.chdir(mutant_folders)
                    os.chdir('ligandoutput')
                    with open(template_name+'_out.pdbqt',"r") as outfile:
                        data = outfile.readlines()
                    for line in data:
                        if 'REMARK VINA RESULT' in line:
                            score_line = line
                            best_score = score_line.split()[3]
                            #print(best_score)
                            break
                            
                            
                    ligandmol2 = pmol.read_mol2(mutant_mol2path)
                    ATOM = pmol.df
                
                    ref = (0, 0, 0)
                    distances = ligandmol2.distance(xyz=ref)
                    distances_df = pd.DataFrame({'Distance':distances, 'X':ATOM['x'],'Y':ATOM['y'],'Z':ATOM['z']})


                    largestdistance_df = distances_df.nlargest(1, 'Distance')
                    x_large_filtered_df = pd.DataFrame(largestdistance_df, columns =['X'])
                    y_large_filtered_df = pd.DataFrame(largestdistance_df, columns =['Y'])
                    z_large_filtered_df = pd.DataFrame(largestdistance_df, columns =['Z'])
                    x_large_array = x_large_filtered_df.to_numpy()
                    y_large_array = y_large_filtered_df.to_numpy()
                    z_large_array = z_large_filtered_df.to_numpy()


                    smallestdistance_df = distances_df.nsmallest(1, 'Distance')
                    x_small_filtered_df = pd.DataFrame(smallestdistance_df, columns =['X'])
                    y_small_filtered_df = pd.DataFrame(smallestdistance_df, columns =['Y'])
                    z_small_filtered_df = pd.DataFrame(smallestdistance_df, columns =['Z'])
                    x_small_array = x_small_filtered_df.to_numpy()
                    y_small_array = y_small_filtered_df.to_numpy()
                    z_small_array = z_small_filtered_df.to_numpy()
                    

                    x_midpoint = x_small_array + ((x_large_array - x_small_array)/2)
                    #print(x_midpoint)
                    y_midpoint = y_small_array + ((y_large_array - y_small_array)/2)
                    #print(y_midpoint)
                    z_midpoint = z_small_array + ((z_large_array - z_small_array)/2)
                    #print(z_midpoint)

                    x_coords = ATOM['x'].to_numpy()
                    y_coords = ATOM['y'].to_numpy()
                    z_coords = ATOM['z'].to_numpy()


                    x_coord_differences = []
                    for item in x_coords:
                        x_coord_differences.append(item - x_midpoint)
                    x_abs_max = max(x_coord_differences, key = abs)
                    x_abs_max_coord = x_midpoint + x_abs_max

                    y_coord_differences = []
                    for item in y_coords:
                        y_coord_differences.append(item - y_midpoint)
                    y_abs_max = max(y_coord_differences, key = abs)
                    y_abs_max_coord = y_midpoint + y_abs_max

                    z_coord_differences = []
                    for item in z_coords:
                        z_coord_differences.append(item - z_midpoint)
                    z_abs_max = max(z_coord_differences, key = abs)
                    z_abs_max_coord = z_midpoint + z_abs_max


                    x_coord_differences_2 = []
                    for item in x_coords:
                        x_coord_differences_2.append(item - x_abs_max_coord)
                    x_abs_max_2 = max(x_coord_differences_2, key = abs)
                    x_abs_max_2_coord = (x_abs_max_coord + x_abs_max_2)
                    x_abs_max_list = (x_abs_max_coord, x_abs_max_2_coord)
                    x_abs_max_list_sorted = sorted(x_abs_max_list)
                    x_upper = x_abs_max_list_sorted[1]
                    x_lower = x_abs_max_list_sorted[0]

                    y_coord_differences_2 = []
                    for item in y_coords:
                        y_coord_differences_2.append(item - y_abs_max_coord)
                    y_abs_max_2 = max(y_coord_differences_2, key = abs)
                    y_abs_max_2_coord = (y_abs_max_coord + y_abs_max_2)
                    y_abs_max_list = (y_abs_max_coord, y_abs_max_2_coord)
                    y_abs_max_list_sorted = sorted(y_abs_max_list)
                    y_upper = y_abs_max_list_sorted[1]
                    y_lower = y_abs_max_list_sorted[0]

                    z_coord_differences_2 = []
                    for item in z_coords:
                        z_coord_differences_2.append(item - z_abs_max_coord)
                    z_abs_max_2 = max(z_coord_differences_2, key = abs)
                    z_abs_max_2_coord = (z_abs_max_coord + z_abs_max_2)
                    z_abs_max_list = (z_abs_max_coord, z_abs_max_2_coord)
                    z_abs_max_list_sorted = sorted(z_abs_max_list)
                    z_upper = z_abs_max_list_sorted[1]
                    z_lower = z_abs_max_list_sorted[0]

                    x_center_array = x_lower + ((x_upper - x_lower)/2)
                    y_center_array = y_lower + ((y_upper - y_lower)/2)
                    z_center_array = z_lower + ((z_upper - z_lower)/2)
                    
                    x_center = x_center_array.item(0)
                    y_center = y_center_array.item(0)
                    z_center = z_center_array.item(0)
                    
                    mutant_ligand_center = x_center,y_center,z_center
                            
                            
                    proteinpdb = ppdb.read_pdb(mutant_pdbpath)
                    ATOM = ppdb.df['ATOM']=ppdb.df['ATOM'][ppdb.df['ATOM']['residue_number'] == float(reference_residue)]
                
        
                    distance = proteinpdb.distance(xyz = mutant_ligand_center, records=('ATOM',))
                    distancedf = pd.DataFrame({'MUT Residue': ATOM['residue_name'], 'MUT Residue Number': ATOM['residue_number'], 'MUT Residue Atom': ATOM['atom_name'], 'MUT Distance': distance, 'MUT Ligand': template_name, 'MUT Protein': protein_name+"_AlphaFold", 'MUT Score': best_score, 'MUT Drug X': x_center, 'MUT Drug Y': y_center, 'MUT Drug Z': z_center}, columns=['MUT Protein','MUT Ligand','MUT Residue','MUT Residue Number', 'MUT Residue Atom', 'MUT Distance', 'MUT Score', 'MUT Drug X', 'MUT Drug Y', 'MUT Drug Z'])
                    distancedf_small = distancedf.nsmallest(1, 'MUT Distance')
                    print(ndistancedf_small)
                    print(distancedf_small)
                    appended_smalldistance.append(distancedf_small)
                nsmalldistance_df = pd.concat(nappended_smalldistance,ignore_index=True)
                smalldistance_df = pd.concat(appended_smalldistance,ignore_index=True)
            
                native_mutant_df= pd.concat([nsmalldistance_df, smalldistance_df], sort=False, axis=1,)
                native_mutant_sorted_df = native_mutant_df.sort_values(by=['ORG Ligand'], ascending=True)
            
                os.chdir(mutant_folders)
                native_mutant_dftocsv = native_mutant_sorted_df.to_csv(mutantcsv, index=False)
                os.chdir(root_dir)
 """
print("done")
